require 'aruba/cucumber'
Aruba.configure do |config|
  config.exit_timeout = 2
end
