#include <stdlib.h>

int main() {
	void *mem = malloc(1024);
	return 0;
}
