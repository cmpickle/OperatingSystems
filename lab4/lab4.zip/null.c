#include <stdio.h>

int main() {
int *test = NULL;
*test = 0;

return 0;
}
